'use client';

import React, { useState, useEffect } from 'react';
import Image from 'next/image';
import { motion, AnimatePresence } from 'motion/react';
import {
  Shield,
  Sparkles,
  CheckCircle,
  HelpCircle,
  Users,
  Home,
  CloudLightning,
  AlertCircle,
  TrendingUp,
  ExternalLink,
  Lock,
  CreditCard,
  Check,
  ChevronRight,
  ShoppingBag,
  Trash2,
  X,
  Minus,
  Plus,
  Play,
  Moon,
  VolumeX,
  Heart,
  Eye,
  ArrowRight,
  RefreshCw,
  Award,
  Calendar,
  Clock,
  Database,
  AlertTriangle,
  Clipboard
} from 'lucide-react';

import { getSupabaseClient } from '@/lib/supabase';

// Import our beautiful product photography assets
import heroImage from '@/src/assets/images/buzzshield_hero_1783239384309.jpg';
import lifestyleImage from '@/src/assets/images/buzzshield_lifestyle_1783239399433.jpg';
import closeupImage from '@/src/assets/images/buzzshield_closeup_1783239413299.jpg';
import packagingImage from '@/src/assets/images/buzzshield_packaging_1783239426704.jpg';

// Define product variants
interface ProductVariant {
  id: string;
  name: string;
  tagline: string;
  price: number;
  originalPrice: number;
  description: string;
  units: number;
  badge?: string;
  popular?: boolean;
}

const PRODUCTS: ProductVariant[] = [
  {
    id: 'bz-solo',
    name: 'BuzzShield Solo',
    tagline: 'Perfect for a single bedroom or home office',
    price: 89,
    originalPrice: 129,
    description: 'Includes 1x BuzzShield Smart Mosquito Killer Lamp, 1x USB-C premium braided power cord, and a 1-year product warranty.',
    units: 1,
    badge: 'Single Room Guard'
  },
  {
    id: 'bz-duo',
    name: 'BuzzShield Sanctuary Duo',
    tagline: 'Best for standard apartments & master bedrooms',
    price: 159,
    originalPrice: 258,
    description: 'Includes 2x BuzzShield Smart Mosquito Killer Lamps, 2x premium braided power cords, and a 2-year extended warranty. Free Shipping included.',
    units: 2,
    badge: 'Most Popular',
    popular: true
  },
  {
    id: 'bz-family',
    name: 'BuzzShield Perimeter Quad',
    tagline: 'Complete perimeter defense for large families',
    price: 279,
    originalPrice: 516,
    description: 'Includes 4x BuzzShield Smart Mosquito Killer Lamps for seamless multi-room coverage, 4x braided power cords, plus a 3-year luxury warranty & premium priority support.',
    units: 4,
    badge: 'Maximum Family Value'
  }
];

export default function BuzzShieldPage() {
  // Cart state
  const [cart, setCart] = useState<{ product: ProductVariant; quantity: number }[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);

  // Diagnostic advisor state (The examination)
  const [quizStep, setQuizStep] = useState(0);
  const [quizAnswers, setQuizAnswers] = useState<Record<string, string>>({});
  const [quizCompleted, setQuizCompleted] = useState(false);

  // Checkout gateway state
  const [checkoutStep, setCheckoutStep] = useState<'cart' | 'details' | 'payment' | 'processing' | 'success'>('cart');
  const [shippingDetails, setShippingDetails] = useState({
    fullName: '',
    email: '',
    address: '',
    city: '',
    zip: '',
    phone: ''
  });
  const [paymentDetails, setPaymentDetails] = useState({
    cardholder: '',
    cardNumber: '',
    expiry: '',
    cvc: ''
  });
  const [processingStatus, setProcessingStatus] = useState<string>('Initializing Secure Vault...');
  const [processingProgress, setProcessingProgress] = useState(0);
  const [orderId, setOrderId] = useState('');

  // Appointment Booking states
  const [bookingName, setBookingName] = useState('');
  const [bookingEmail, setBookingEmail] = useState('');
  const [bookingPhone, setBookingPhone] = useState('');
  const [bookingAddress, setBookingAddress] = useState('');
  const [bookingDate, setBookingDate] = useState('');
  const [bookingTime, setBookingTime] = useState('10:00 AM');
  const [bookingNotes, setBookingNotes] = useState('');
  const [bookingDeviceVariant, setBookingDeviceVariant] = useState('Sanctuary Duo');
  const [bookingStatus, setBookingStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');
  const [bookingMessage, setBookingMessage] = useState('');
  const [supabaseSqlToRun, setSupabaseSqlToRun] = useState('');
  const [showSqlSetupHelper, setShowSqlSetupHelper] = useState(false);

  const handleBookAppointment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!bookingName || !bookingEmail || !bookingDate || !bookingTime) {
      alert('Please fill out all required fields.');
      return;
    }

    setBookingStatus('submitting');
    setBookingMessage('');
    setSupabaseSqlToRun('');
    setShowSqlSetupHelper(false);

    try {
      const supabase = getSupabaseClient();
      const exposureRisk = quizStep === 4 ? getDiagnosticRecommendation().title : 'Standard Exposure';

      // Insert record into the 'appointments' table in Supabase directly
      const { data: record, error } = await supabase
        .from('appointments')
        .insert([
          {
            full_name: bookingName,
            email: bookingEmail,
            phone: bookingPhone || '',
            address: bookingAddress || '',
            appointment_date: bookingDate,
            appointment_time: bookingTime,
            device_variant: bookingDeviceVariant || 'Standard',
            exposure_risk: exposureRisk,
            notes: bookingNotes || '',
            created_at: new Date().toISOString()
          }
        ])
        .select();

      if (error) {
        console.error('Supabase error inserting appointment:', error);
        
        // If the table doesn't exist, we give a friendly, helpful error message
        if (error.code === '42P01') {
          setBookingStatus('error');
          setBookingMessage('The "appointments" table does not exist in your Supabase database yet. Please click the "Setup Supabase Database Table" button on the screen to run the SQL snippet in your Supabase dashboard SQL Editor.');
          setSupabaseSqlToRun(`
CREATE TABLE appointments (
  id BIGSERIAL PRIMARY KEY,
  full_name TEXT NOT NULL,
  email TEXT NOT NULL,
  phone TEXT,
  address TEXT,
  appointment_date TEXT NOT NULL,
  appointment_time TEXT NOT NULL,
  device_variant TEXT,
  exposure_risk TEXT,
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL
);

ALTER TABLE appointments ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Enable insert access for all users" ON appointments FOR INSERT WITH CHECK (true);
CREATE POLICY "Enable select access for all users" ON appointments FOR SELECT USING (true);
          `);
          setShowSqlSetupHelper(true);
        } else {
          setBookingStatus('error');
          setBookingMessage(error.message || 'Failed to save appointment to Supabase. Please verify your Supabase settings.');
        }
      } else {
        setBookingStatus('success');
        setBookingMessage('Your installation & tuning appointment has been successfully scheduled and saved directly to your Supabase table!');
        // Clear inputs on success
        setBookingName('');
        setBookingEmail('');
        setBookingPhone('');
        setBookingAddress('');
        setBookingDate('');
        setBookingNotes('');
      }
    } catch (error: any) {
      console.error('Error submitting booking:', error);
      setBookingStatus('error');
      setBookingMessage('An error occurred while connecting to Supabase. Please check your network and Supabase configuration.');
    }
  };

  // Active picture gallery tab
  const [galleryIndex, setGalleryIndex] = useState(0);

  // Reassurance tooltips & specs states
  const [activeSpecIndex, setActiveSpecIndex] = useState(0);

  const imagesList = [
    { src: heroImage, title: 'Front Angle Hero Shot', desc: 'Minimalist studio presentation showcasing the matte deep teal body and soft UV light core.' },
    { src: lifestyleImage, title: 'Lifestyle in Living Room', desc: 'Sleek integration on bedroom or living spaces, providing silent nighttime protection.' },
    { src: closeupImage, title: 'Close-up UV Glow Core', desc: 'Fine safety protective grid housing the advanced 365nm mosquito attraction wave.' },
    { src: packagingImage, title: 'Retail Unboxing Experience', desc: 'Eco-friendly cardboard gift packaging showcasing modern accessories.' }
  ];

  const specs = [
    {
      title: '365nm Optical Resonance',
      desc: 'Mimics the exact biotherm wavelength that human beings naturally emit, attracting mosquitoes with zero toxic chemical sprays.',
      icon: Sparkles
    },
    {
      title: 'Ozone-Free & Eco Safe',
      desc: 'Unlike old electric bug zappers, BuzzShield releases zero chemicals, radiation, or odors. It is completely safe next to baby cribs.',
      icon: Shield
    },
    {
      title: '18dB Whisper Quiet Fan',
      desc: 'Equipped with a custom brushless vortex suction motor that hums below the sound of a rustling leaf, securing sleep without noise.',
      icon: VolumeX
    },
    {
      title: 'Active Escape-Proof Mesh',
      desc: 'A secondary high-density tactile physical chamber locks mosquitoes securely. It keeps them insulated until they naturally dehydrate.',
      icon: Lock
    }
  ];

  // Helper functions for cart
  const addToCart = (product: ProductVariant) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.product.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [...prev, { product, quantity: 1 }];
    });
    setIsCartOpen(true);
    setCheckoutStep('cart');
  };

  const removeFromCart = (id: string) => {
    setCart((prev) => prev.filter((item) => item.product.id !== id));
  };

  const updateQuantity = (id: string, delta: number) => {
    setCart((prev) =>
      prev
        .map((item) => {
          if (item.product.id === id) {
            const nextQty = item.quantity + delta;
            return { ...item, quantity: nextQty };
          }
          return item;
        })
        .filter((item) => item.quantity > 0)
    );
  };

  const getCartTotal = () => {
    return cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  };

  const getCartUnitsCount = () => {
    return cart.reduce((sum, item) => sum + item.quantity, 0);
  };

  // Formatting helpers for secure checkout
  const formatCardNumber = (value: string) => {
    const v = value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
    const matches = v.match(/\d{4,16}/g);
    const match = (matches && matches[0]) || '';
    const parts = [];

    for (let i = 0, len = match.length; i < len; i += 4) {
      parts.push(match.substring(i, i + 4));
    }

    if (parts.length > 0) {
      return parts.join(' ');
    } else {
      return v;
    }
  };

  const formatExpiry = (value: string) => {
    const v = value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
    if (v.length >= 2) {
      return `${v.slice(0, 2)}/${v.slice(2, 4)}`;
    }
    return v;
  };

  // Mock secure processing simulation
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (checkoutStep === 'processing') {
      const steps = [
        { progress: 15, msg: 'Connecting to BuzzShield Secure Escrow Server...' },
        { progress: 35, msg: 'Verifying PCI-DSS compliance handshake...' },
        { progress: 55, msg: 'Encrypting 256-bit tokenized gateway ledger...' },
        { progress: 75, msg: 'Authorizing simulated charge with banking hub...' },
        { progress: 95, msg: 'Generating digital receipt & security key...' },
        { progress: 100, msg: 'Transaction Completed Successfully!' }
      ];

      let currentStepIndex = 0;
      const runProgress = () => {
        if (currentStepIndex < steps.length) {
          const s = steps[currentStepIndex];
          setProcessingProgress(s.progress);
          setProcessingStatus(s.msg);
          currentStepIndex++;
          timer = setTimeout(runProgress, 800);
        } else {
          setOrderId(`BZS-${Math.floor(100000 + Math.random() * 900000)}`);
          setCheckoutStep('success');
          setCart([]); // Clear cart on success
        }
      };

      timer = setTimeout(runProgress, 400);
    }
    return () => clearTimeout(timer);
  }, [checkoutStep]);

  // Quiz diagnostic config (reassuring setup advisor)
  const quizQuestions = [
    {
      id: 'household',
      title: 'Who lives in your home environment?',
      subtitle: 'Understanding residents allows us to customize the safety configuration.',
      options: [
        { label: 'Infants & Children', value: 'infants', description: 'Requires silent operation and non-radiation zero chemical guarantees.' },
        { label: 'Loved Pets (Dogs, Cats, Birds)', value: 'pets', description: 'Requires silent motors and high safety grid mesh to prevent curiosity.' },
        { label: 'Adults & Seniors', value: 'adults', description: 'Requires reliable overnight containment and soft-glowing eye-safety light.' }
      ],
      reassurance: 'Every BuzzShield is 100% toxic-free, chemical-free, and emits no fumes or radiation. Sleep in pure comfort alongside those you cherish.'
    },
    {
      id: 'layout',
      title: 'What is the physical footprint of your space?',
      subtitle: 'Mosquito behavior is highly spatial. We analyze square footage to prevent blind spots.',
      options: [
        { label: 'Single Bedroom / Studio', value: 'small', description: 'Perfect for a single unit. Focus is placed directly in sleeping paths.' },
        { label: 'Multi-Room Apartment', value: 'medium', description: 'Requires dual placement (e.g. Living space entry + Master bedroom corner).' },
        { label: 'Multi-Story House / Estate', value: 'large', description: 'Requires perimeter defenses across common zones and individual bedroom sanctuaries.' }
      ],
      reassurance: 'Perimeter coverage ensures mosquitoes are attracted at entry points before they ever reach the bed.'
    },
    {
      id: 'climate',
      title: 'What environmental factors are nearby?',
      subtitle: 'External dampness directly impacts interior mosquito entry risk.',
      options: [
        { label: 'Close to lakes, ponds, or garden pools', value: 'water', description: 'High seasonal breeding hazard. Continuous evening perimeter operation is highly recommended.' },
        { label: 'Heavy tree canopy / lush lawn foliage', value: 'foliage', description: 'Moderate-high hazard. Insects shelter in humid grass and enters during open doors.' },
        { label: 'Dry urban or concrete surrounds', value: 'urban', description: 'Low-moderate hazard. Protection focuses mostly on nighttime patio entry.' }
      ],
      reassurance: 'A structured setup shields your home regardless of external conditions. There is no need for worry; your home is safe.'
    }
  ];

  const handleQuizAnswer = (qId: string, value: string) => {
    setQuizAnswers((prev) => ({ ...prev, [qId]: value }));
    if (quizStep < quizQuestions.length - 1) {
      setQuizStep((prev) => prev + 1);
    } else {
      setQuizCompleted(true);
    }
  };

  const resetQuiz = () => {
    setQuizStep(0);
    setQuizAnswers({});
    setQuizCompleted(false);
  };

  // Recommender logic based on "examination"
  const getDiagnosticRecommendation = () => {
    const { layout, climate } = quizAnswers;
    let units = 1;
    let title = 'Single Sanctuary Setup';
    let selectedProd = PRODUCTS[0];

    if (layout === 'medium' || climate === 'foliage') {
      units = 2;
      title = 'Duo Sanctuary Shield';
      selectedProd = PRODUCTS[1];
    } else if (layout === 'large' || climate === 'water') {
      units = 4;
      title = 'Quad Family Perimeter Shield';
      selectedProd = PRODUCTS[2];
    }

    return {
      units,
      title,
      product: selectedProd,
      rationale: `Based on your environment, we recommend placing ${units} ${units === 1 ? 'unit' : 'strategically coordinated units'} to cover your space safely. Keep them active on side tables. Continuous evening runtimes will keep your family completely safe without any aggressive zapping noises.`,
      setupTip: 'Ensure units are placed 3 feet off the ground and away from high drafts. Keep them active continuously in sleeping quarters to establish a reliable safety zone.'
    };
  };

  return (
    <div id="app-root" className="min-h-screen bg-[#F7F9FA] text-[#1A1A1A] font-sans selection:bg-[#BEFD29] selection:text-[#0D3B3E]">
      
      {/* 1. Header Navigation - Styled in elegant light/dark geometric balance */}
      <header id="app-nav" className="sticky top-0 z-40 bg-white border-b border-[#0D3B3E]/10 py-5 px-6 md:px-12 text-[#0D3B3E] transition-all">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-[#0D3B3E] flex items-center justify-center shadow-md relative overflow-hidden group">
              <div className="absolute inset-0 bg-[#BEFD29] opacity-0 group-hover:opacity-10 transition-opacity" />
              <Shield className="w-5 h-5 text-[#BEFD29] relative z-10" />
            </div>
            <div>
              <span className="text-2xl font-bold tracking-tighter text-[#0D3B3E]">
                BUZZ<span className="text-[#0D3B3E]/60">SHIELD</span>
              </span>
              <p className="text-[9px] font-mono tracking-widest text-[#0D3B3E]/50 uppercase font-bold">Safe-Home Tech</p>
            </div>
          </div>

          <nav className="hidden md:flex items-center gap-10 text-xs font-semibold uppercase tracking-widest text-[#0D3B3E]/70">
            <a href="#hero" className="hover:text-[#0D3B3E] transition-colors relative group py-1">
              Technology
              <span className="absolute bottom-0 left-0 w-0 h-[2px] bg-[#BEFD29] group-hover:w-full transition-all duration-300" />
            </a>
            <a href="#advisor" className="hover:text-[#0D3B3E] transition-colors relative group py-1">
              Safety Advisor
              <span className="absolute bottom-0 left-0 w-0 h-[2px] bg-[#BEFD29] group-hover:w-full transition-all duration-300" />
            </a>
            <a href="#booking" className="hover:text-[#0D3B3E] transition-colors relative group py-1 font-bold text-[#0D3B3E]">
              Book Appointment
              <span className="absolute bottom-0 left-0 w-0 h-[2px] bg-[#BEFD29] group-hover:w-full transition-all duration-300" />
            </a>
            <a href="#features" className="hover:text-[#0D3B3E] transition-colors relative group py-1">
              Core Science
              <span className="absolute bottom-0 left-0 w-0 h-[2px] bg-[#BEFD29] group-hover:w-full transition-all duration-300" />
            </a>
            <a href="#gallery" className="hover:text-[#0D3B3E] transition-colors relative group py-1">
              Reviews & Details
              <span className="absolute bottom-0 left-0 w-0 h-[2px] bg-[#BEFD29] group-hover:w-full transition-all duration-300" />
            </a>
            <a href="#buy" className="hover:text-[#0D3B3E] transition-colors relative group py-1">
              Support & pricing
              <span className="absolute bottom-0 left-0 w-0 h-[2px] bg-[#BEFD29] group-hover:w-full transition-all duration-300" />
            </a>
          </nav>

          <div className="flex items-center gap-4">
            <button
              onClick={() => {
                setCheckoutStep('cart');
                setIsCartOpen(true);
              }}
              className="relative w-10 h-10 border border-[#0D3B3E]/10 hover:border-[#0D3B3E] flex items-center justify-center cursor-pointer hover:bg-slate-50 transition-colors text-[#0D3B3E] group"
              aria-label="Open shopping cart"
            >
              <ShoppingBag className="w-5 h-5" />
              {getCartUnitsCount() > 0 && (
                <span className="absolute -top-1.5 -right-1.5 flex h-5 w-5 items-center justify-center rounded-full bg-[#BEFD29] text-[#0D3B3E] text-[10px] font-bold shadow-md border border-[#0D3B3E]">
                  {getCartUnitsCount()}
                </span>
              )}
            </button>
            <a
              href="#buy"
              className="hidden sm:inline-flex items-center justify-center px-6 py-3 bg-[#0D3B3E] text-[#BEFD29] font-bold uppercase tracking-widest text-xs rounded-none hover:bg-[#154e52] transition-all cursor-pointer shadow-md"
            >
              Buy Now
            </a>
          </div>
        </div>
      </header>

      {/* 2. Hero Section - Pure Geometric Balance editorial layout */}
      <section id="hero" className="relative bg-[#F7F9FA] text-[#0D3B3E] pt-16 pb-24 px-6 md:px-12 overflow-hidden border-b border-[#0D3B3E]/5">
        {/* Abstract geometric background */}
        <div className="absolute w-[500px] h-[500px] bg-[#0D3B3E] rounded-full opacity-5 -z-0 -top-24 -left-24 pointer-events-none" />
        <div className="absolute bottom-10 right-0 w-[450px] h-[350px] bg-[#BEFD29] rounded-tl-[120px] -z-0 opacity-10 pointer-events-none" />
        
        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center relative z-10">
          
          {/* Hero Content Left */}
          <div className="lg:col-span-6 flex flex-col items-start space-y-8">
            <div className="inline-flex items-center gap-3">
              <span className="w-8 h-[2px] bg-[#BEFD29]"></span>
              <span className="text-[#0D3B3E] font-bold text-xs uppercase tracking-[0.3em]">2024 Design Award Winner</span>
            </div>

            <h1 className="text-[52px] sm:text-[68px] lg:text-[80px] leading-[0.9] font-bold text-[#0D3B3E] tracking-tighter mb-4">
              The Silent <br/>Guardian.
            </h1>

            <p className="text-lg text-[#0D3B3E]/70 max-w-lg leading-relaxed font-sans">
              Experience ultimate sanctuary. Our proprietary UV-A core technology targets pests with clinical precision while maintaining a whisper-quiet, beautiful presence in your home.
            </p>

            {/* Quick trust metrics - styled as geometric clean divides */}
            <div className="grid grid-cols-3 gap-8 w-full py-6 border-y border-[#0D3B3E]/10">
              <div>
                <p className="text-3xl font-bold text-[#0D3B3E] tracking-tight">100%</p>
                <p className="text-xs text-[#0D3B3E]/50 font-semibold uppercase tracking-wider mt-1">Chemical-Free</p>
              </div>
              <div>
                <p className="text-3xl font-bold text-[#0D3B3E] tracking-tight">18dB</p>
                <p className="text-xs text-[#0D3B3E]/50 font-semibold uppercase tracking-wider mt-1">Ultra-Quiet</p>
              </div>
              <div>
                <p className="text-3xl font-bold text-[#0D3B3E] tracking-tight">5W</p>
                <p className="text-xs text-[#0D3B3E]/50 font-semibold uppercase tracking-wider mt-1">Eco-Efficient</p>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 w-full sm:w-auto pt-2">
              <a
                href="#buy"
                className="px-10 py-5 bg-[#0D3B3E] text-[#BEFD29] font-bold uppercase tracking-widest text-sm rounded-none hover:bg-[#154e52] transition-all text-center shadow-lg active:scale-95 cursor-pointer"
              >
                Buy Now — $89.00
              </a>
              <a
                href="#advisor"
                className="px-8 py-5 border-2 border-[#0D3B3E] text-[#0D3B3E] font-bold uppercase tracking-widest text-xs rounded-none hover:bg-[#0D3B3E] hover:text-[#BEFD29] transition-all text-center active:scale-95 cursor-pointer flex items-center justify-center gap-2"
              >
                <HelpCircle className="w-4 h-4" /> Analyze Your Home
              </a>
            </div>

            <div className="flex items-center gap-3 text-[#0D3B3E]/60 text-xs font-semibold uppercase tracking-wider">
              <Check className="w-4 h-4 text-[#0D3B3E]" /> Safety Rating: A++ Certified
              <span className="text-[#0D3B3E]/20">|</span>
              <Check className="w-4 h-4 text-[#0D3B3E]" /> 30-Day Sleep Guarantee
            </div>
          </div>

          {/* Hero Image Right - Interleaving photography with the beautiful CSS Product Mockup */}
          <div className="lg:col-span-6 relative flex flex-col md:flex-row items-center justify-center gap-8">
            {/* The photography block with Neo-Brutalist offset shadow */}
            <div className="relative w-full aspect-[4/5] max-w-[320px] bg-[#1A1A1A] border-4 border-[#0D3B3E] shadow-[12px_12px_0px_0px_#0D3B3E] overflow-hidden group">
              <Image
                src={heroImage}
                alt="BuzzShield Premium Mosquito Killer Lamp front hero shot"
                fill
                priority
                referrerPolicy="no-referrer"
                className="object-cover transition-transform duration-700 group-hover:scale-105"
              />
              <div className="absolute bottom-4 left-4 right-4 bg-[#0D3B3E] text-[#BEFD29] p-3 text-left font-mono text-[10px] uppercase tracking-wider">
                Studio Hero Photograph
              </div>
            </div>

            {/* CSS Product Mockup: The BuzzShield Lamp from Design Instructions */}
            <div className="relative z-10 shrink-0 hidden md:block">
              <div className="w-52 h-72 bg-[#1A1A1A] rounded-[50px] relative shadow-2xl overflow-hidden border-[6px] border-[#0D3B3E]/20">
                {/* Matte Top Cap */}
                <div className="absolute top-0 w-full h-10 bg-[#2A2A2A] border-b border-white/5"></div>
                
                {/* UV Core Glow */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-20 h-44 bg-gradient-to-b from-[#8B5CF6] via-[#6366F1] to-[#8B5CF6] rounded-full blur-[35px] opacity-60 animate-pulse"></div>
                  <div className="w-3.5 h-36 bg-white/20 rounded-full blur-[1.5px]"></div>
                </div>

                {/* Protective Grille Ribs */}
                <div className="absolute inset-0 flex justify-around px-5 py-10 pointer-events-none">
                  <div className="w-[1px] h-full bg-white/10"></div>
                  <div className="w-[1px] h-full bg-white/10"></div>
                  <div className="w-[1px] h-full bg-white/10"></div>
                  <div className="w-[1px] h-full bg-white/10"></div>
                </div>

                {/* Status LED */}
                <div className="absolute bottom-8 left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-[#BEFD29] shadow-[0_0_8px_#BEFD29]"></div>
              </div>
              {/* Reflection Shadow */}
              <div className="w-52 h-8 bg-black/10 blur-xl rounded-full mt-3 mx-auto"></div>

              {/* Floating Detail */}
              <div className="absolute -top-10 -right-10 bg-white p-5 shadow-xl rounded-none border-2 border-[#0D3B3E] max-w-[170px] z-20">
                <div className="flex items-center gap-2 mb-1.5">
                  <div className="w-2.5 h-2.5 bg-[#BEFD29]"></div>
                  <span className="text-[9px] font-bold uppercase tracking-widest text-[#0D3B3E]">Family Safe</span>
                </div>
                <p className="text-[10px] leading-tight text-gray-500">Chemical-free. Zero odors. Zero noise.</p>
              </div>
            </div>
          </div>

        </div>
      </section>

      {/* 3. Reassurance & Diagnostic Advisor (The "Examine" Tool) */}
      <section id="advisor" className="py-24 px-6 md:px-12 bg-white">
        <div className="max-w-4xl mx-auto">
          
          <div className="text-center space-y-4 mb-16">
            <span className="text-xs uppercase font-bold tracking-widest text-[#0D3B3E] font-mono bg-[#BEFD29] text-[#0D3B3E] px-4 py-1">
              Personalized Evaluation
            </span>
            <h2 className="text-3xl md:text-5xl font-bold tracking-tighter text-[#0D3B3E]">
              Examine Your Space Protection Plan
            </h2>
            <p className="text-slate-600 max-w-xl mx-auto text-sm md:text-base leading-relaxed">
              Identify your home demographics and exposure level. We will determine the optimal safety layout and continuous zapping-free protection coordinates.
            </p>
          </div>

          {/* Diagnostic Card Container in pristine geometric style */}
          <div className="bg-white rounded-none border-4 border-[#0D3B3E] shadow-[12px_12px_0px_0px_#0D3B3E] overflow-hidden">
            <div className="bg-[#0D3B3E] py-6 px-8 text-white flex items-center justify-between">
              <div className="flex items-center gap-3">
                <HelpCircle className="w-5 h-5 text-[#BEFD29]" />
                <div>
                  <h3 className="font-bold text-sm uppercase tracking-wider">Space Setup & Placement Advisor</h3>
                  <p className="text-[11px] text-white/60">Evaluating safety, layout, and localized risk factors</p>
                </div>
              </div>
              <div className="text-right">
                <span className="text-[10px] text-white/50 uppercase font-mono">Step</span>
                <p className="text-sm font-bold text-[#BEFD29] font-mono">{quizCompleted ? 'Final' : `${quizStep + 1} / ${quizQuestions.length}`}</p>
              </div>
            </div>

            {/* Progress Bar */}
            <div className="h-1.5 bg-[#0D3B3E]/10 w-full relative">
              <div
                className="h-full bg-[#BEFD29] transition-all duration-300"
                style={{ width: quizCompleted ? '100%' : `${((quizStep) / quizQuestions.length) * 100}%` }}
              />
            </div>

            <div className="p-8 md:p-10 bg-[#F7F9FA]">
              <AnimatePresence mode="wait">
                {!quizCompleted ? (
                  <motion.div
                    key={quizStep}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: -20, x: -20 }}
                    className="space-y-6"
                  >
                    <div>
                      <h4 className="text-xl font-bold text-[#0D3B3E] tracking-tight">
                        {quizQuestions[quizStep].title}
                      </h4>
                      <p className="text-slate-500 text-sm mt-1">
                        {quizQuestions[quizStep].subtitle}
                      </p>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      {quizQuestions[quizStep].options.map((option) => (
                        <button
                          key={option.value}
                          onClick={() => handleQuizAnswer(quizQuestions[quizStep].id, option.value)}
                          className={`p-5 rounded-none text-left border-2 transition-all group relative cursor-pointer flex flex-col justify-between h-full ${
                            quizAnswers[quizQuestions[quizStep].id] === option.value
                              ? 'border-[#0D3B3E] bg-[#0D3B3E]/5 shadow-[4px_4px_0px_0px_#0D3B3E]'
                              : 'border-slate-200 hover:border-[#0D3B3E]/50 bg-white'
                          }`}
                        >
                          <div>
                            <span className="text-sm font-bold text-[#0D3B3E] tracking-tight block">
                              {option.label}
                            </span>
                            <p className="text-slate-500 text-[11px] mt-2 leading-relaxed">
                              {option.description}
                            </p>
                          </div>
                          <div className="mt-4 flex justify-end w-full">
                            <span className="w-5 h-5 rounded-full border border-slate-300 flex items-center justify-center group-hover:border-[#0D3B3E] transition-colors">
                              {quizAnswers[quizQuestions[quizStep].id] === option.value && (
                                <span className="w-2.5 h-2.5 rounded-full bg-[#0D3B3E]" />
                              )}
                            </span>
                          </div>
                        </button>
                      ))}
                    </div>

                    {/* Warm Reassurance Panel */}
                    <div className="p-4 rounded-none bg-[#0D3B3E]/5 border border-[#0D3B3E]/10 flex gap-3 items-start">
                      <AlertCircle className="w-5 h-5 text-[#0D3B3E] shrink-0 mt-0.5" />
                      <div>
                        <span className="text-[10px] font-bold text-[#0D3B3E] block uppercase tracking-wider font-mono">Safety Assurance</span>
                        <p className="text-slate-600 text-xs mt-1 leading-relaxed">
                          {quizQuestions[quizStep].reassurance}
                        </p>
                      </div>
                    </div>
                  </motion.div>
                ) : (
                  <motion.div
                    key="results"
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="space-y-6"
                  >
                    <div className="text-center py-4">
                      <div className="w-14 h-14 bg-[#0D3B3E] rounded-full flex items-center justify-center mx-auto text-[#BEFD29] border border-[#0D3B3E]/10">
                        <Award className="w-7 h-7 text-[#BEFD29]" />
                      </div>
                      <h4 className="text-2xl font-bold text-[#0D3B3E] mt-4 tracking-tight">
                        Custom Protection Blueprint
                      </h4>
                      <p className="text-slate-500 text-xs uppercase font-mono tracking-widest mt-1">
                        Tailored for your family & home layout
                      </p>
                    </div>

                    <div className="p-6 md:p-8 rounded-none bg-white border-2 border-[#0D3B3E] shadow-[6px_6px_0px_0px_#0D3B3E] grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
                      <div className="md:col-span-8 space-y-4">
                        <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-[#BEFD29] text-[#0D3B3E] font-bold text-[10px] uppercase tracking-wider">
                          <CheckCircle className="w-3.5 h-3.5" /> Recommended: {getDiagnosticRecommendation().title}
                        </span>
                        <p className="text-[#0D3B3E] font-semibold text-base leading-relaxed">
                          {getDiagnosticRecommendation().rationale}
                        </p>
                        
                        {/* Placement rule reassurance */}
                        <p className="text-slate-500 text-xs leading-relaxed border-t border-slate-100 pt-3">
                          <strong className="text-[#0D3B3E] uppercase font-mono text-[10px] tracking-wider block mb-1">Crucial Setup Rule:</strong> {getDiagnosticRecommendation().setupTip} Once placed, keep active continuously. Do not separate your BuzzShield from sleeping chambers during evening hours to maintain full protection.
                        </p>
                      </div>

                      <div className="md:col-span-4 border-t md:border-t-0 md:border-l border-slate-200 pt-6 md:pt-0 md:pl-6 flex flex-col items-center justify-center space-y-3 text-center">
                        <div className="space-y-1">
                          <p className="text-slate-400 text-xs line-through font-mono">
                            ${getDiagnosticRecommendation().product.originalPrice} USD
                          </p>
                          <p className="text-4xl font-bold text-[#0D3B3E] font-mono tracking-tight">
                            ${getDiagnosticRecommendation().product.price} USD
                          </p>
                          <p className="text-[#0D3B3E] text-[10px] uppercase font-bold tracking-widest font-mono px-3 py-1 bg-[#BEFD29] inline-block mt-1">
                            Save ${(getDiagnosticRecommendation().product.originalPrice - getDiagnosticRecommendation().product.price)} USD
                          </p>
                        </div>

                        <button
                          onClick={() => addToCart(getDiagnosticRecommendation().product)}
                          className="w-full inline-flex items-center justify-center gap-2 px-6 py-4 bg-[#0D3B3E] text-[#BEFD29] hover:bg-[#1a5b60] font-bold text-xs uppercase tracking-widest rounded-none transition-all shadow-md cursor-pointer active:scale-95"
                        >
                          <ShoppingBag className="w-4 h-4 text-[#BEFD29]" /> Adopt Recommendation
                        </button>
                      </div>
                    </div>

                    <div className="flex justify-between items-center pt-6 border-t border-slate-200">
                      <button
                        onClick={resetQuiz}
                        className="text-[#0D3B3E] hover:text-[#185d63] font-bold text-xs uppercase tracking-wider flex items-center gap-1.5 cursor-pointer"
                      >
                        <RefreshCw className="w-3.5 h-3.5" /> Re-Examine Space
                      </button>
                      <span className="text-slate-400 text-xs font-mono">Calculated real-time</span>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>

        </div>
      </section>

      {/* 3.5. Supabase Appointment Booking Section */}
      <section id="booking" className="py-24 px-6 md:px-12 bg-white border-b border-[#0D3B3E]/5">
        <div className="max-w-7xl mx-auto space-y-16">
          <div className="text-center space-y-4">
            <span className="text-xs uppercase font-bold tracking-widest text-[#0D3B3E] font-mono bg-[#BEFD29] text-[#0D3B3E] px-4 py-1">
              Durable Cloud Sync Enabled
            </span>
            <h2 className="text-3xl md:text-5xl font-bold tracking-tighter text-[#0D3B3E]">
              Book an Installation & Setup Appointment
            </h2>
            <p className="text-slate-600 max-w-2xl mx-auto text-sm md:text-base leading-relaxed">
              Schedule a premium, 1-on-1 space tuning and positioning consultation. All appointments are processed in real-time and saved directly into your <strong>Supabase</strong> account for durable persistence.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
            
            {/* Form Column */}
            <div className="lg:col-span-7 bg-[#F7F9FA] border-2 border-[#0D3B3E]/10 p-8 shadow-[6px_6px_0px_0px_rgba(13,59,62,0.05)] rounded-none">
              <h3 className="text-lg font-bold text-[#0D3B3E] tracking-tight mb-6 flex items-center gap-2">
                <Calendar className="w-5 h-5 text-[#0D3B3E]" /> 1. Select Date & Contact Details
              </h3>

              <form onSubmit={handleBookAppointment} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="text-[10px] font-bold uppercase text-slate-500 block mb-1">Full Name *</label>
                    <input
                      type="text"
                      required
                      placeholder="Jane Doe"
                      value={bookingName}
                      onChange={(e) => setBookingName(e.target.value)}
                      className="w-full px-4 py-3 bg-white border-2 border-slate-200 text-sm focus:outline-none focus:border-[#0D3B3E] font-sans"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold uppercase text-slate-500 block mb-1">Email Address *</label>
                    <input
                      type="email"
                      required
                      placeholder="janedoe@example.com"
                      value={bookingEmail}
                      onChange={(e) => setBookingEmail(e.target.value)}
                      className="w-full px-4 py-3 bg-white border-2 border-slate-200 text-sm focus:outline-none focus:border-[#0D3B3E] font-sans"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="text-[10px] font-bold uppercase text-slate-500 block mb-1">Phone Number</label>
                    <input
                      type="tel"
                      placeholder="+1 (555) 019-2834"
                      value={bookingPhone}
                      onChange={(e) => setBookingPhone(e.target.value)}
                      className="w-full px-4 py-3 bg-white border-2 border-slate-200 text-sm focus:outline-none focus:border-[#0D3B3E] font-sans"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold uppercase text-slate-500 block mb-1">Installation Address</label>
                    <input
                      type="text"
                      placeholder="123 Serene Sleeping Lane, SF"
                      value={bookingAddress}
                      onChange={(e) => setBookingAddress(e.target.value)}
                      className="w-full px-4 py-3 bg-white border-2 border-slate-200 text-sm focus:outline-none focus:border-[#0D3B3E] font-sans"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="text-[10px] font-bold uppercase text-slate-500 block mb-1">Preferred Date *</label>
                    <div className="relative">
                      <input
                        type="date"
                        required
                        value={bookingDate}
                        onChange={(e) => setBookingDate(e.target.value)}
                        className="w-full pl-10 pr-4 py-3 bg-white border-2 border-slate-200 text-sm focus:outline-none focus:border-[#0D3B3E] font-mono"
                      />
                      <Calendar className="w-4 h-4 text-slate-400 absolute left-3.5 top-4 pointer-events-none" />
                    </div>
                  </div>
                  <div>
                    <label className="text-[10px] font-bold uppercase text-slate-500 block mb-1">Preferred Time Slot *</label>
                    <div className="relative">
                      <select
                        value={bookingTime}
                        onChange={(e) => setBookingTime(e.target.value)}
                        className="w-full pl-10 pr-4 py-3 bg-white border-2 border-slate-200 text-sm focus:outline-none focus:border-[#0D3B3E] appearance-none font-sans"
                      >
                        <option value="09:00 AM">09:00 AM (Early Morning)</option>
                        <option value="11:00 AM">11:00 AM (Late Morning)</option>
                        <option value="02:00 PM">02:00 PM (Early Afternoon)</option>
                        <option value="04:00 PM">04:00 PM (Late Afternoon)</option>
                        <option value="07:00 PM">07:00 PM (Evening Guidance)</option>
                      </select>
                      <Clock className="w-4 h-4 text-slate-400 absolute left-3.5 top-4 pointer-events-none" />
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="text-[10px] font-bold uppercase text-slate-500 block mb-1">Recommended Device Setup</label>
                    <select
                      value={bookingDeviceVariant}
                      onChange={(e) => setBookingDeviceVariant(e.target.value)}
                      className="w-full px-4 py-3 bg-white border-2 border-slate-200 text-sm focus:outline-none focus:border-[#0D3B3E] font-sans"
                    >
                      <option value="Sanctuary Duo">Sanctuary Duo (2 Rooms / Moderate Exposure)</option>
                      <option value="Solo Shield">Solo Shield (1 Room / Low Exposure)</option>
                      <option value="Perimeter Quad">Perimeter Quad (4 Rooms / High Exposure)</option>
                      <option value="Consultation Only">Consultation Only (Custom Layout Evaluation)</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-[10px] font-bold uppercase text-slate-500 block mb-1">Diagnostic Exposure Risk</label>
                    <input
                      type="text"
                      disabled
                      value={quizStep === 4 ? getDiagnosticRecommendation().title : 'Standard (Diagnostic incomplete)'}
                      className="w-full px-4 py-3 bg-slate-100 border-2 border-slate-200 text-sm text-slate-500 font-sans font-semibold cursor-not-allowed"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-[10px] font-bold uppercase text-slate-500 block mb-1">Additional Notes / Stagnant Water Concerns</label>
                  <textarea
                    rows={3}
                    placeholder="E.g. We have an open terrace, heavy vegetation nearby, or small toddlers in the house."
                    value={bookingNotes}
                    onChange={(e) => setBookingNotes(e.target.value)}
                    className="w-full px-4 py-3 bg-white border-2 border-slate-200 text-sm focus:outline-none focus:border-[#0D3B3E] font-sans"
                  />
                </div>

                {bookingStatus === 'submitting' ? (
                  <button
                    disabled
                    className="w-full py-4 bg-[#0D3B3E]/60 text-white font-bold text-xs uppercase tracking-widest flex items-center justify-center gap-2"
                  >
                    <RefreshCw className="w-4 h-4 animate-spin" /> Saving Securely to Supabase...
                  </button>
                ) : (
                  <button
                    type="submit"
                    className="w-full py-4 bg-[#0D3B3E] text-[#BEFD29] hover:bg-[#1a5b60] font-bold text-xs uppercase tracking-widest transition-all shadow-md cursor-pointer text-center rounded-none"
                  >
                    Book Appointment & Sync to Supabase
                  </button>
                )}

                {bookingMessage && (
                  <div className={`p-4 text-xs font-semibold flex items-start gap-2.5 ${
                    bookingStatus === 'success' ? 'bg-[#BEFD29]/20 text-[#0D3B3E] border border-[#BEFD29]/50' : 'bg-red-50 text-red-700 border border-red-200'
                  }`}>
                    {bookingStatus === 'success' ? (
                      <CheckCircle className="w-4.5 h-4.5 text-[#0D3B3E] shrink-0" />
                    ) : (
                      <AlertTriangle className="w-4.5 h-4.5 text-red-600 shrink-0" />
                    )}
                    <div className="space-y-1">
                      <p>{bookingMessage}</p>
                      {showSqlSetupHelper && (
                        <button
                          type="button"
                          onClick={() => setShowSqlSetupHelper(!showSqlSetupHelper)}
                          className="text-red-800 underline hover:text-red-950 block mt-1"
                        >
                          Toggle SQL Guide instructions
                        </button>
                      )}
                    </div>
                  </div>
                )}
              </form>
            </div>

            {/* Supabase Dashboard Console Column */}
            <div className="lg:col-span-5 space-y-6">
              
              {/* Connection Status Card */}
              <div className="bg-[#0D3B3E] text-white p-6 border-2 border-[#0D3B3E] shadow-[6px_6px_0px_0px_#BEFD29] rounded-none space-y-6">
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-2">
                    <Database className="w-5 h-5 text-[#BEFD29]" />
                    <span className="font-mono text-xs uppercase font-bold tracking-widest text-[#BEFD29]">Supabase Cloud Sync</span>
                  </div>
                  <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 bg-[#BEFD29]/20 text-[#BEFD29] text-[9px] font-bold uppercase tracking-wider font-mono">
                    ● CONNECTED
                  </span>
                </div>

                <div className="space-y-3.5 border-t border-white/10 pt-4">
                  <div className="text-xs flex justify-between items-center">
                    <span className="text-slate-400 font-semibold">Project ID:</span>
                    <span className="font-mono font-bold bg-white/5 px-2 py-0.5 text-white">qqyjjnmqytlmxpgnxlak</span>
                  </div>
                  <div className="text-xs flex justify-between items-center">
                    <span className="text-slate-400 font-semibold">Table Target:</span>
                    <span className="font-mono font-bold bg-white/5 px-2 py-0.5 text-[#BEFD29]">appointments</span>
                  </div>
                  <div className="text-xs flex justify-between items-center">
                    <span className="text-slate-400 font-semibold">API Auth Type:</span>
                    <span className="font-mono font-bold bg-white/5 px-2 py-0.5 text-white">Service Anon / Public</span>
                  </div>
                </div>

                <div className="p-3.5 bg-white/5 border border-white/10 text-xs text-slate-300 leading-normal space-y-2">
                  <span className="font-bold text-[#BEFD29] block text-[10px] uppercase tracking-wider font-mono">Synced Schema Definition</span>
                  <p className="text-[11px] text-slate-300">
                    Your appointment fields are compiled into a relational structure and inserted via securely proxies:
                  </p>
                  <div className="font-mono text-[9px] text-slate-400 bg-black/35 p-2 space-y-1 select-all overflow-x-auto">
                    <div>full_name (Text)</div>
                    <div>email (Text)</div>
                    <div>phone (Text)</div>
                    <div>address (Text)</div>
                    <div>appointment_date (Text)</div>
                    <div>appointment_time (Text)</div>
                    <div>device_variant (Text)</div>
                    <div>exposure_risk (Text)</div>
                    <div>notes (Text)</div>
                  </div>
                </div>
              </div>

              {/* SQL setup copy container */}
              <div className="bg-[#F7F9FA] border-2 border-slate-200 p-6 rounded-none space-y-4">
                <div className="flex justify-between items-center">
                  <h4 className="font-bold text-[#0D3B3E] text-xs uppercase tracking-wider font-mono flex items-center gap-2">
                    <Database className="w-4 h-4" /> Supabase SQL Setup Code
                  </h4>
                  <button
                    type="button"
                    onClick={() => {
                      const code = `CREATE TABLE appointments (
  id BIGSERIAL PRIMARY KEY,
  full_name TEXT NOT NULL,
  email TEXT NOT NULL,
  phone TEXT,
  address TEXT,
  appointment_date TEXT NOT NULL,
  appointment_time TEXT NOT NULL,
  device_variant TEXT,
  exposure_risk TEXT,
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL
);

ALTER TABLE appointments ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Enable insert access for all users" ON appointments FOR INSERT WITH CHECK (true);
CREATE POLICY "Enable select access for all users" ON appointments FOR SELECT USING (true);`;
                      navigator.clipboard.writeText(code);
                      alert('Copied SQL Setup code to clipboard!');
                    }}
                    className="text-[10px] font-bold text-[#0D3B3E] uppercase hover:underline cursor-pointer"
                  >
                    Copy SQL
                  </button>
                </div>
                <p className="text-[11px] text-slate-500 leading-normal">
                  To ensure Supabase can store your data, run this migration in your Supabase SQL Editor. It sets up the table and grants secure public insertion access:
                </p>
                <pre className="font-mono text-[9px] bg-slate-900 text-slate-300 p-4 overflow-x-auto max-h-48 border border-slate-950 leading-relaxed">
{`CREATE TABLE appointments (
  id BIGSERIAL PRIMARY KEY,
  full_name TEXT NOT NULL,
  email TEXT NOT NULL,
  phone TEXT,
  address TEXT,
  appointment_date TEXT NOT NULL,
  appointment_time TEXT NOT NULL,
  device_variant TEXT,
  exposure_risk TEXT,
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL
);

ALTER TABLE appointments ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Enable insert access for all users" ON appointments FOR INSERT WITH CHECK (true);
CREATE POLICY "Enable select access for all users" ON appointments FOR SELECT USING (true);`}
                </pre>
              </div>

            </div>

          </div>
        </div>
      </section>

      {/* 4. Core Science & Features */}
      <section id="features" className="py-24 px-6 md:px-12 bg-[#F7F9FA] relative border-t border-b border-[#0D3B3E]/5">
        <div className="max-w-7xl mx-auto">
          
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            {/* Features Left Column */}
            <div className="lg:col-span-5 space-y-8">
              <div className="space-y-4">
                <span className="text-xs uppercase font-bold tracking-widest text-[#0D3B3E] font-mono bg-[#BEFD29] text-[#0D3B3E] px-4 py-1">
                  Pediatric-Safe Technology
                </span>
                <h2 className="text-3xl sm:text-5xl font-bold tracking-tighter text-[#0D3B3E] leading-tight">
                  Designed for Reassurance.<br />
                  Silent, Odorless Defense.
                </h2>
                <p className="text-slate-600 leading-relaxed text-sm sm:text-base">
                  Traditional zappers rely on burning high-voltage grids and aerosol repellents that can pose health risks to children and pets. 
                  BuzzShield reimagines household insect care through gentle biological optical resonance.
                </p>
              </div>

              {/* Specs Stack - Styled in Geometric Balance blocks */}
              <div className="space-y-4">
                {specs.map((spec, idx) => {
                  const IconComp = spec.icon;
                  return (
                    <button
                      key={idx}
                      onClick={() => setActiveSpecIndex(idx)}
                      className={`w-full text-left p-5 rounded-none border-2 transition-all flex gap-4 cursor-pointer ${
                        activeSpecIndex === idx
                          ? 'border-[#0D3B3E] bg-white shadow-[4px_4px_0px_0px_#0D3B3E]'
                          : 'border-slate-200/60 hover:border-slate-300 bg-white'
                      }`}
                    >
                      <div className={`p-2.5 rounded-none ${
                        activeSpecIndex === idx ? 'bg-[#0D3B3E] text-[#BEFD29]' : 'bg-slate-100 text-[#0D3B3E]'
                      }`}>
                        <IconComp className="w-5 h-5" />
                      </div>
                      <div>
                        <h4 className="font-bold text-[#0D3B3E] text-sm md:text-base tracking-tight">{spec.title}</h4>
                        {activeSpecIndex === idx && (
                          <p className="text-slate-600 text-xs md:text-sm mt-2 leading-relaxed">
                            {spec.desc}
                          </p>
                        )}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Features Right Column (Glow Detail Rendering) */}
            <div className="lg:col-span-7 flex flex-col items-center">
              <div className="relative w-full aspect-video rounded-none border-4 border-[#0D3B3E] shadow-[12px_12px_0px_0px_#BEFD29] overflow-hidden">
                <Image
                  src={closeupImage}
                  alt="Close-up photograph of safe glowing UV blue-purple light core"
                  fill
                  referrerPolicy="no-referrer"
                  className="object-cover"
                />
                
                {/* Floating Tech Specifications Card */}
                <div className="absolute bottom-6 left-6 right-6 p-5 bg-[#0D3B3E]/95 text-white flex justify-between items-center border border-white/10">
                  <div>
                    <span className="text-[10px] text-[#BEFD29] font-mono tracking-widest block uppercase font-bold">Macro Detail View</span>
                    <p className="text-xs text-white/80 mt-1">High-density physical shield prevents accidental finger contact with the core.</p>
                  </div>
                  <span className="px-3 py-1 bg-[#BEFD29] text-[#0D3B3E] text-[10px] font-mono uppercase font-bold">
                    365nm Optical Core
                  </span>
                </div>
              </div>

              <p className="text-slate-400 text-xs mt-4 italic text-center">
                Detailed 4K studio photography of BuzzShield protective outer mesh and optical frequency lamp core.
              </p>
            </div>

          </div>

        </div>
      </section>

      {/* 5. Design Details / Photography Showcase */}
      <section id="gallery" className="py-24 px-6 md:px-12 bg-[#1A1A1A] text-white">
        <div className="max-w-7xl mx-auto space-y-12">
          
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
            <div className="space-y-4">
              <span className="text-xs uppercase font-bold tracking-widest text-[#BEFD29] font-mono bg-[#BEFD29]/10 border border-[#BEFD29]/20 px-4 py-1">
                4K Commercial Photography
              </span>
              <h2 className="text-3xl sm:text-5xl font-bold tracking-tighter">
                Crafted Design Showcase
              </h2>
              <p className="text-slate-400 max-w-xl text-sm md:text-base leading-relaxed">
                Examine our premium modern aesthetic. Deep teal textures, safe glowing cores, and luxury ecological unboxing layouts captured in absolute high-definition.
              </p>
            </div>

            <div className="flex flex-wrap gap-2">
              {imagesList.map((img, index) => (
                <button
                  key={index}
                  onClick={() => setGalleryIndex(index)}
                  className={`px-5 py-3 rounded-none text-xs font-semibold uppercase tracking-widest transition-all cursor-pointer ${
                    galleryIndex === index
                      ? 'bg-[#BEFD29] text-[#0D3B3E]'
                      : 'bg-[#2A2A2A] border border-[#2A2A2A] text-slate-300 hover:text-white hover:border-slate-500'
                  }`}
                >
                  {img.title}
                </button>
              ))}
            </div>
          </div>

          {/* Gallery Viewfinder - Geometric style */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
            
            {/* Main Visual Display */}
            <div className="lg:col-span-8 relative aspect-video rounded-none bg-slate-950 border-4 border-[#0D3B3E] shadow-2xl flex items-center justify-center overflow-hidden">
              <Image
                src={imagesList[galleryIndex].src}
                alt={imagesList[galleryIndex].title}
                fill
                referrerPolicy="no-referrer"
                className="object-cover"
              />
              <div className="absolute top-4 left-4 py-1.5 px-3 bg-black/75 border border-white/10 text-slate-300 text-[10px] font-mono uppercase tracking-widest">
                IMAGE {galleryIndex + 1} OF 4
              </div>
            </div>

            {/* Viewfinder Information */}
            <div className="lg:col-span-4 bg-[#2A2A2A] border border-[#2A2A2A] p-8 rounded-none flex flex-col justify-between space-y-6">
              <div className="space-y-4">
                <span className="text-[10px] font-mono tracking-widest text-[#BEFD29] uppercase block font-bold">
                  Interactive Specifications
                </span>
                <h3 className="text-2xl font-bold text-white tracking-tight">
                  {imagesList[galleryIndex].title}
                </h3>
                <p className="text-slate-300 text-sm leading-relaxed">
                  {imagesList[galleryIndex].desc}
                </p>

                <div className="space-y-3 pt-6 border-t border-white/5">
                  <div className="flex items-center gap-2.5 text-xs text-slate-300">
                    <Check className="w-4 h-4 text-[#BEFD29]" /> Matte Deep Teal finish (#0D3B3E)
                  </div>
                  <div className="flex items-center gap-2.5 text-xs text-slate-300">
                    <Check className="w-4 h-4 text-[#BEFD29]" /> Electric Lime accents (#BEFD29)
                  </div>
                  <div className="flex items-center gap-2.5 text-xs text-slate-300">
                    <Check className="w-4 h-4 text-[#BEFD29]" /> 365nm Glowing UV Core
                  </div>
                </div>
              </div>

              {/* Mini thumbnails selection strip */}
              <div className="grid grid-cols-4 gap-2 pt-6 border-t border-white/5">
                {imagesList.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => setGalleryIndex(idx)}
                    className={`relative aspect-square rounded-none overflow-hidden border-2 transition-all cursor-pointer ${
                      galleryIndex === idx ? 'border-[#BEFD29] scale-95 shadow-md' : 'border-[#3A3A3A] hover:border-slate-500'
                    }`}
                  >
                    <Image
                      src={img.src}
                      alt={`Thumbnail ${idx}`}
                      fill
                      referrerPolicy="no-referrer"
                      className="object-cover"
                    />
                  </button>
                ))}
              </div>
            </div>

          </div>

        </div>
      </section>

      {/* 6. Product Packaging / Unboxing Section */}
      <section className="py-24 px-6 md:px-12 bg-white">
        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          <div className="lg:col-span-6 relative aspect-square max-w-[460px] mx-auto rounded-none border-4 border-[#0D3B3E] shadow-[12px_12px_0px_0px_#0D3B3E] overflow-hidden">
            <Image
              src={packagingImage}
              alt="BuzzShield eco-friendly luxury cardboard retail packaging box design"
              fill
              referrerPolicy="no-referrer"
              className="object-cover"
            />
            <div className="absolute bottom-4 left-4 py-1.5 px-3 bg-[#0D3B3E] text-[#BEFD29] text-[10px] font-mono uppercase tracking-widest">
              Flat Lay Box Presentation
            </div>
          </div>

          <div className="lg:col-span-6 space-y-6">
            <span className="text-xs uppercase font-bold tracking-widest text-[#0D3B3E] font-mono bg-[#BEFD29] text-[#0D3B3E] px-4 py-1">
              Ecological Commitment
            </span>
            <h2 className="text-3xl md:text-5xl font-bold tracking-tighter text-[#0D3B3E]">
              A Premium Unboxing Journey
            </h2>
            <p className="text-slate-600 text-sm md:text-base leading-relaxed">
              Every BuzzShield is shipped in zero-plastic, 100% biodegradable corrugated fibers printed with organic soy inks. 
              The premium presentation reflects the quality of modern family-safe smart appliances inside, making it an excellent gift.
            </p>

            <div className="space-y-5 pt-6 border-t border-slate-100">
              <div className="flex gap-4">
                <div className="p-1 rounded-full bg-[#0D3B3E]/5 text-[#0D3B3E] h-fit">
                  <Check className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="font-bold text-[#0D3B3E] text-sm tracking-tight">Braided USB-C Cord Included</h4>
                  <p className="text-slate-500 text-xs mt-1">Premium-weighted deep teal nylon-braided protective insulation prevents pet biting hazards.</p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="p-1 rounded-full bg-[#0D3B3E]/5 text-[#0D3B3E] h-fit">
                  <Check className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="font-bold text-[#0D3B3E] text-sm tracking-tight">2-Year Extended Warranty Certificate</h4>
                  <p className="text-slate-500 text-xs mt-1">A guarantee certificate enclosed in every luxury box to solidify our commitment to your comfort.</p>
                </div>
              </div>
            </div>
          </div>

        </div>
      </section>

      {/* 7. Science & CDC Resource Guidelines */}
      <section id="science" className="py-24 px-6 md:px-12 bg-[#0D3B3E] text-white relative">
        <div className="max-w-7xl mx-auto space-y-16">
          
          <div className="text-center space-y-4">
            <span className="text-xs uppercase font-bold tracking-widest text-[#BEFD29] font-mono bg-[#BEFD29]/10 border border-[#BEFD29]/25 px-4 py-1">
              Trusted Guidelines
            </span>
            <h2 className="text-3xl md:text-5xl font-bold tracking-tighter">
              Evidence-Based Vector Protection
            </h2>
            <p className="text-slate-300 max-w-xl mx-auto text-sm md:text-base leading-relaxed">
              Explore scientifically approved procedures for mosquito control. We combine premium physical design with recommendations from global health organizations.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            
            {/* Card 1 */}
            <div className="bg-[#14565b] border-2 border-white/5 p-8 flex flex-col justify-between space-y-8 rounded-none transition-all hover:shadow-[8px_8px_0px_0px_#BEFD29]">
              <div className="space-y-4">
                <span className="text-[10px] font-mono uppercase tracking-widest text-[#BEFD29] font-bold">CDC Vector Prevention</span>
                <h4 className="text-lg font-bold text-white tracking-tight">CDC Guidelines on Standing Water</h4>
                <p className="text-slate-300 text-xs leading-relaxed">
                  The Center for Disease Control recommends draining stagnant puddles, cleaning rain gutters weekly, and ensuring septic system integrity. Standing water acts as the primary breeding medium for disease-carrying insect vectors.
                </p>
              </div>
              <a
                href="https://www.cdc.gov/mosquitoes/prevention/index.html"
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1.5 text-xs font-bold text-[#BEFD29] uppercase tracking-wider hover:underline pt-4 border-t border-white/5"
              >
                View CDC Mosquito Guides <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>

            {/* Card 2 */}
            <div className="bg-[#14565b] border-2 border-white/5 p-8 flex flex-col justify-between space-y-8 rounded-none transition-all hover:shadow-[8px_8px_0px_0px_#BEFD29]">
              <div className="space-y-4">
                <span className="text-[10px] font-mono uppercase tracking-widest text-[#BEFD29] font-bold">WHO Environmental Strategy</span>
                <h4 className="text-lg font-bold text-white tracking-tight">WHO Integrated Management</h4>
                <p className="text-slate-300 text-xs leading-relaxed">
                  World Health Organization guides highlight physical perimeters (such as dense insect meshes, window screens, and zapping-free vacuum trap devices) as highly sustainable first-line protections that protect ecological balances.
                </p>
              </div>
              <a
                href="https://www.who.int/news-room/fact-sheets/detail/vector-borne-diseases"
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1.5 text-xs font-bold text-[#BEFD29] uppercase tracking-wider hover:underline pt-4 border-t border-white/5"
              >
                View WHO Vector Guidelines <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>

            {/* Card 3 */}
            <div className="bg-[#14565b] border-2 border-white/5 p-8 flex flex-col justify-between space-y-8 rounded-none transition-all hover:shadow-[8px_8px_0px_0px_#BEFD29]">
              <div className="space-y-4">
                <span className="text-[10px] font-mono uppercase tracking-widest text-[#BEFD29] font-bold">EPA Eco Safety Regulations</span>
                <h4 className="text-lg font-bold text-white tracking-tight">EPA Chemical Repellent Safety</h4>
                <p className="text-slate-300 text-xs leading-relaxed">
                  The Environmental Protection Agency details proper applications of chemical repellents. When infants are in household structures, non-chemical traps like BuzzShield serve as an outstanding zero-toxicity nighttime alternative.
                </p>
              </div>
              <a
                href="https://www.epa.gov/insect-repellents"
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1.5 text-xs font-bold text-[#BEFD29] uppercase tracking-wider hover:underline pt-4 border-t border-white/5"
              >
                View EPA Repellent Registry <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>

          </div>

        </div>
      </section>

      {/* 8. Pricing & Packages - Highly Styled Geometric Balance columns */}
      <section id="buy" className="py-24 px-6 md:px-12 bg-[#F7F9FA]">
        <div className="max-w-7xl mx-auto space-y-16">
          
          <div className="text-center space-y-4">
            <span className="text-xs uppercase font-bold tracking-widest text-[#0D3B3E] font-mono bg-[#BEFD29] text-[#0D3B3E] px-4 py-1">
              Guaranteed Satisfaction
            </span>
            <h2 className="text-3xl md:text-5xl font-bold tracking-tighter text-[#0D3B3E]">
              Adopt Your Perimeter Defense
            </h2>
            <p className="text-slate-600 max-w-xl mx-auto text-sm md:text-base leading-relaxed">
              Secure every bedroom in your home. Risk-free purchase with safe shipping, direct support, and automated 30-day sleep protection guarantee.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-stretch pt-4">
            {PRODUCTS.map((prod) => (
              <div
                key={prod.id}
                className={`p-8 bg-white flex flex-col justify-between relative transition-all rounded-none ${
                  prod.popular
                    ? 'border-4 border-[#0D3B3E] shadow-[12px_12px_0px_0px_#BEFD29] scale-105 z-10'
                    : 'border-2 border-[#0D3B3E]/10 hover:border-[#0D3B3E] shadow-[6px_6px_0px_0px_rgba(13,59,62,0.05)]'
                }`}
              >
                {prod.badge && (
                  <span className={`absolute -top-3 left-1/2 -translate-x-1/2 px-4 py-1 text-[10px] font-bold uppercase tracking-wider shadow-sm ${
                    prod.popular ? 'bg-[#0D3B3E] text-[#BEFD29]' : 'bg-slate-200 text-slate-700'
                  }`}>
                    {prod.badge}
                  </span>
                )}

                <div className="space-y-6">
                  <div>
                    <h3 className="text-2xl font-bold text-[#0D3B3E] tracking-tight">{prod.name}</h3>
                    <p className="text-slate-500 text-xs mt-1.5 leading-relaxed font-semibold">{prod.tagline}</p>
                  </div>

                  <div className="flex items-baseline gap-2 pb-6 border-b border-slate-100">
                    <span className="text-4xl font-bold text-[#0D3B3E] font-mono tracking-tight">${prod.price}</span>
                    <span className="text-slate-400 font-mono line-through text-sm">${prod.originalPrice}</span>
                    <span className="text-xs text-slate-500 font-sans uppercase font-bold tracking-wider">USD</span>
                  </div>

                  <p className="text-slate-600 text-xs leading-relaxed">{prod.description}</p>

                  <div className="space-y-3 py-4 bg-slate-50 rounded-none p-4 border border-slate-100">
                    <p className="text-xs font-semibold text-[#0D3B3E] flex items-center gap-2.5">
                      <CheckCircle className="w-4 h-4 text-[#0D3B3E]" /> Safe for children & pets
                    </p>
                    <p className="text-xs font-semibold text-[#0D3B3E] flex items-center gap-2.5">
                      <CheckCircle className="w-4 h-4 text-[#0D3B3E]" /> USB-C braided insulation cords
                    </p>
                    <p className="text-xs font-semibold text-[#0D3B3E] flex items-center gap-2.5">
                      <CheckCircle className="w-4 h-4 text-[#0D3B3E]" /> Silent 18dB air suction vortex
                    </p>
                  </div>
                </div>

                <div className="pt-8">
                  <button
                    onClick={() => addToCart(prod)}
                    className={`w-full inline-flex items-center justify-center gap-2 py-4 font-bold text-xs uppercase tracking-widest transition-all rounded-none shadow-md active:scale-95 cursor-pointer ${
                      prod.popular
                        ? 'bg-[#0D3B3E] text-[#BEFD29] hover:bg-[#154e52]'
                        : 'border-2 border-[#0D3B3E] text-[#0D3B3E] hover:bg-[#0D3B3E] hover:text-[#BEFD29]'
                    }`}
                  >
                    <ShoppingBag className="w-4.5 h-4.5" /> Adopt Protection
                  </button>
                  <p className="text-slate-400 text-[10px] text-center mt-3 font-semibold uppercase tracking-wider">
                    30-Day Money-Back Guarantee Included
                  </p>
                </div>
              </div>
            ))}
          </div>

        </div>
      </section>

      {/* 9. Interactive Payment Gateway / Shopping Cart Sliding Drawer */}
      <AnimatePresence>
        {isCartOpen && (
          <>
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.5 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsCartOpen(false)}
              className="fixed inset-0 bg-black z-50 pointer-events-auto"
            />

            {/* Sliding Panel - Styled in pristine Geometric Balance */}
            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed right-0 top-0 bottom-0 w-full max-w-md bg-white shadow-2xl z-50 flex flex-col justify-between"
            >
              
              {/* Drawer Header */}
              <div className="bg-[#0D3B3E] text-[#BEFD29] p-6 border-b border-white/5 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Lock className="w-4 h-4 text-[#BEFD29]" />
                  <h3 className="font-bold text-sm uppercase tracking-widest">Secure Checking Hub</h3>
                </div>
                <button
                  onClick={() => setIsCartOpen(false)}
                  className="p-1 rounded bg-[#154e52] hover:bg-[#1C646A] text-[#BEFD29] cursor-pointer"
                  aria-label="Close checkout"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Drawer Content Area */}
              <div className="flex-1 overflow-y-auto p-6 space-y-6">
                
                {/* Checkout Step Steps Indicator */}
                {checkoutStep !== 'processing' && checkoutStep !== 'success' && (
                  <div className="flex items-center justify-between py-2 border-b border-[#0D3B3E]/10 text-[10px] uppercase tracking-widest font-bold">
                    <button
                      disabled={checkoutStep === 'cart'}
                      onClick={() => setCheckoutStep('cart')}
                      className={`${checkoutStep === 'cart' ? 'text-[#0D3B3E] font-bold' : 'text-slate-400 hover:text-[#0D3B3E]'}`}
                    >
                      1. Cart
                    </button>
                    <ChevronRight className="w-3 h-3 text-slate-300" />
                    <button
                      disabled={cart.length === 0 || checkoutStep === 'details'}
                      onClick={() => setCheckoutStep('details')}
                      className={`${checkoutStep === 'details' ? 'text-[#0D3B3E] font-bold' : 'text-slate-400 hover:text-[#0D3B3E]'}`}
                    >
                      2. Delivery
                    </button>
                    <ChevronRight className="w-3 h-3 text-slate-300" />
                    <span className={`${checkoutStep === 'payment' ? 'text-[#0D3B3E] font-bold' : 'text-slate-400'}`}>
                      3. Payment
                    </span>
                  </div>
                )}

                <AnimatePresence mode="wait">
                  
                  {/* STEP 1: CART LIST */}
                  {checkoutStep === 'cart' && (
                    <motion.div
                      key="cart-step"
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      className="space-y-4"
                    >
                      {cart.length === 0 ? (
                        <div className="text-center py-12 space-y-4">
                          <ShoppingBag className="w-12 h-12 text-slate-300 mx-auto" />
                          <h4 className="font-bold text-slate-600">Your shopping cart is empty</h4>
                          <p className="text-xs text-slate-400">Adopt a protective safety package to secure your home.</p>
                          <button
                            onClick={() => setIsCartOpen(false)}
                            className="inline-flex items-center justify-center px-6 py-3 bg-[#0D3B3E] text-[#BEFD29] text-xs font-bold uppercase tracking-widest rounded-none cursor-pointer"
                          >
                            Browse Products
                          </button>
                        </div>
                      ) : (
                        <div className="space-y-4">
                          {cart.map((item) => (
                            <div key={item.product.id} className="p-4 rounded-none bg-[#F7F9FA] border-2 border-[#0D3B3E]/10 flex justify-between gap-4">
                              <div className="flex-1 space-y-1">
                                <span className="text-[9px] font-mono uppercase font-bold text-[#0D3B3E] bg-[#BEFD29] px-2 py-0.5">
                                  {item.product.units} {item.product.units === 1 ? 'Lamp' : 'Lamps'}
                                </span>
                                <h4 className="font-bold text-sm text-[#0D3B3E] mt-1.5">{item.product.name}</h4>
                                <p className="text-xs text-slate-400 leading-normal">{item.product.tagline}</p>
                                
                                <div className="flex items-center gap-2 mt-3">
                                  <button
                                    onClick={() => updateQuantity(item.product.id, -1)}
                                    className="p-1 rounded bg-slate-200 hover:bg-slate-300 text-slate-700 cursor-pointer"
                                  >
                                    <Minus className="w-3 h-3" />
                                  </button>
                                  <span className="text-xs font-bold font-mono px-2">{item.quantity}</span>
                                  <button
                                    onClick={() => updateQuantity(item.product.id, 1)}
                                    className="p-1 rounded bg-slate-200 hover:bg-slate-300 text-slate-700 cursor-pointer"
                                  >
                                    <Plus className="w-3 h-3" />
                                  </button>
                                </div>
                              </div>

                              <div className="text-right flex flex-col justify-between items-end">
                                <button
                                  onClick={() => removeFromCart(item.product.id)}
                                  className="p-1 rounded text-red-500 hover:bg-red-50 text-xs flex items-center cursor-pointer"
                                  title="Remove item"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </button>
                                <span className="text-sm font-mono font-bold text-[#0D3B3E]">
                                  ${item.product.price * item.quantity} USD
                                </span>
                              </div>
                            </div>
                          ))}

                          <div className="pt-4 border-t border-slate-100 space-y-3">
                            <div className="flex justify-between text-xs text-slate-500 font-semibold uppercase tracking-wider">
                              <span>Shipping & Logistics</span>
                              <span className="text-[#0D3B3E] font-bold uppercase font-mono bg-[#BEFD29] px-2 py-0.5">Free</span>
                            </div>
                            <div className="flex justify-between text-base font-bold text-[#0D3B3E] pt-1">
                              <span>Perimeter Order Total</span>
                              <span className="font-mono">${getCartTotal()} USD</span>
                            </div>
                          </div>

                          <button
                            onClick={() => setCheckoutStep('details')}
                            className="w-full inline-flex items-center justify-center gap-2 py-4 bg-[#0D3B3E] text-[#BEFD29] hover:bg-[#1a5b60] font-bold text-xs uppercase tracking-widest rounded-none transition-all shadow-md cursor-pointer"
                          >
                            Add Delivery Address <ChevronRight className="w-4 h-4 text-[#BEFD29]" />
                          </button>
                        </div>
                      )}
                    </motion.div>
                  )}

                  {/* STEP 2: DELIVERY DETAILS */}
                  {checkoutStep === 'details' && (
                    <motion.div
                      key="details-step"
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: -20, x: -20 }}
                      className="space-y-4"
                    >
                      <h4 className="text-xs font-bold text-[#0D3B3E] uppercase font-mono tracking-widest">
                        Shipping Recipient Details
                      </h4>

                      <div className="space-y-4">
                        <div>
                          <label className="text-[10px] font-bold uppercase text-slate-400 block mb-1">Full Recipient Name</label>
                          <input
                            type="text"
                            placeholder="John Doe"
                            value={shippingDetails.fullName}
                            onChange={(e) => setShippingDetails({ ...shippingDetails, fullName: e.target.value })}
                            className="w-full px-4 py-3 rounded-none border-2 border-slate-200 text-sm focus:outline-none focus:border-[#0D3B3E]"
                            required
                          />
                        </div>

                        <div>
                          <label className="text-[10px] font-bold uppercase text-slate-400 block mb-1">Contact Email Address</label>
                          <input
                            type="email"
                            placeholder="johndoe@example.com"
                            value={shippingDetails.email}
                            onChange={(e) => setShippingDetails({ ...shippingDetails, email: e.target.value })}
                            className="w-full px-4 py-3 rounded-none border-2 border-slate-200 text-sm focus:outline-none focus:border-[#0D3B3E]"
                            required
                          />
                        </div>

                        <div>
                          <label className="text-[10px] font-bold uppercase text-slate-400 block mb-1">Residential Street Address</label>
                          <input
                            type="text"
                            placeholder="123 Serene Sleeping Lane"
                            value={shippingDetails.address}
                            onChange={(e) => setShippingDetails({ ...shippingDetails, address: e.target.value })}
                            className="w-full px-4 py-3 rounded-none border-2 border-slate-200 text-sm focus:outline-none focus:border-[#0D3B3E]"
                            required
                          />
                        </div>

                        <div className="grid grid-cols-2 gap-3">
                          <div>
                            <label className="text-[10px] font-bold uppercase text-slate-400 block mb-1">City</label>
                            <input
                              type="text"
                              placeholder="San Francisco"
                              value={shippingDetails.city}
                              onChange={(e) => setShippingDetails({ ...shippingDetails, city: e.target.value })}
                              className="w-full px-4 py-3 rounded-none border-2 border-slate-200 text-sm focus:outline-none focus:border-[#0D3B3E]"
                              required
                            />
                          </div>
                          <div>
                            <label className="text-[10px] font-bold uppercase text-slate-400 block mb-1">Zip Code</label>
                            <input
                              type="text"
                              placeholder="94103"
                              value={shippingDetails.zip}
                              onChange={(e) => setShippingDetails({ ...shippingDetails, zip: e.target.value })}
                              className="w-full px-4 py-3 rounded-none border-2 border-slate-200 text-sm focus:outline-none focus:border-[#0D3B3E]"
                              required
                            />
                          </div>
                        </div>

                        <div>
                          <label className="text-[10px] font-bold uppercase text-slate-400 block mb-1">Phone Number (Logistics alerts)</label>
                          <input
                            type="tel"
                            placeholder="+1 (555) 019-2834"
                            value={shippingDetails.phone}
                            onChange={(e) => setShippingDetails({ ...shippingDetails, phone: e.target.value })}
                            className="w-full px-4 py-3 rounded-none border-2 border-slate-200 text-sm focus:outline-none focus:border-[#0D3B3E]"
                            required
                          />
                        </div>
                      </div>

                      <div className="pt-6 border-t border-slate-100 flex gap-3">
                        <button
                          onClick={() => setCheckoutStep('cart')}
                          className="flex-1 py-4 border-2 border-[#0D3B3E] text-[#0D3B3E] font-bold text-xs uppercase tracking-widest hover:bg-slate-50 transition-all cursor-pointer text-center rounded-none"
                        >
                          Back to Cart
                        </button>
                        <button
                          onClick={() => {
                            if (shippingDetails.fullName && shippingDetails.email && shippingDetails.address) {
                              setCheckoutStep('payment');
                            } else {
                              alert('Please fill out all required shipping fields.');
                            }
                          }}
                          className="flex-1 py-4 bg-[#0D3B3E] text-[#BEFD29] hover:bg-[#1a5b60] font-bold text-xs uppercase tracking-widest transition-all shadow-md cursor-pointer text-center rounded-none"
                        >
                          Proceed
                        </button>
                      </div>
                    </motion.div>
                  )}

                  {/* STEP 3: PAYMENT GATEWAY */}
                  {checkoutStep === 'payment' && (
                    <motion.div
                      key="payment-step"
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: -20, x: -20 }}
                      className="space-y-4"
                    >
                      <div className="p-4 bg-[#0D3B3E]/5 border-2 border-[#0D3B3E]/10 space-y-2 rounded-none">
                        <div className="flex items-center gap-2 text-xs font-bold text-[#0D3B3E]">
                          <Lock className="w-4 h-4 text-[#BEFD29]" /> PCI-DSS Secured Token Gateway
                        </div>
                        <p className="text-[11px] text-slate-500 leading-normal">
                          Your connection is protected by 256-bit token cryptography. Real transactions are simulated safely here.
                        </p>
                      </div>

                      <div className="space-y-4">
                        <div>
                          <label className="text-[10px] font-bold uppercase text-slate-400 block mb-1">Cardholder Name</label>
                          <input
                            type="text"
                            placeholder="John Doe"
                            value={paymentDetails.cardholder}
                            onChange={(e) => setPaymentDetails({ ...paymentDetails, cardholder: e.target.value })}
                            className="w-full px-4 py-3 rounded-none border-2 border-slate-200 text-sm focus:outline-none focus:border-[#0D3B3E] uppercase font-mono"
                            required
                          />
                        </div>

                        <div>
                          <label className="text-[10px] font-bold uppercase text-slate-400 block mb-1">Secured Card Number</label>
                          <div className="relative">
                            <input
                              type="text"
                              maxLength={19}
                              placeholder="4111 2222 3333 4444"
                              value={paymentDetails.cardNumber}
                              onChange={(e) => setPaymentDetails({ ...paymentDetails, cardNumber: formatCardNumber(e.target.value) })}
                              className="w-full pl-10 pr-4 py-3 rounded-none border-2 border-slate-200 text-sm focus:outline-none focus:border-[#0D3B3E] font-mono tracking-widest"
                              required
                            />
                            <CreditCard className="w-4 h-4 text-slate-400 absolute left-3.5 top-4" />
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-3">
                          <div>
                            <label className="text-[10px] font-bold uppercase text-slate-400 block mb-1">Expiry Date</label>
                            <input
                              type="text"
                              maxLength={5}
                              placeholder="MM/YY"
                              value={paymentDetails.expiry}
                              onChange={(e) => setPaymentDetails({ ...paymentDetails, expiry: formatExpiry(e.target.value) })}
                              className="w-full px-4 py-3 rounded-none border-2 border-slate-200 text-sm focus:outline-none focus:border-[#0D3B3E] font-mono"
                              required
                            />
                          </div>
                          <div>
                            <label className="text-[10px] font-bold uppercase text-slate-400 block mb-1">CVC Code</label>
                            <input
                              type="password"
                              maxLength={3}
                              placeholder="123"
                              value={paymentDetails.cvc}
                              onChange={(e) => setPaymentDetails({ ...paymentDetails, cvc: e.target.value.replace(/\D/g, '') })}
                              className="w-full px-4 py-3 rounded-none border-2 border-slate-200 text-sm focus:outline-none focus:border-[#0D3B3E] font-mono"
                              required
                            />
                          </div>
                        </div>
                      </div>

                      {/* Display Secure Order Total */}
                      <div className="p-4 bg-slate-50 border border-slate-100 flex justify-between items-center text-xs font-semibold rounded-none">
                        <span className="text-slate-500">Secure Order Charge</span>
                        <span className="font-mono font-bold text-sm text-[#0D3B3E]">${getCartTotal()} USD</span>
                      </div>

                      <div className="pt-6 border-t border-slate-100 flex gap-3">
                        <button
                          onClick={() => setCheckoutStep('details')}
                          className="flex-1 py-4 border-2 border-[#0D3B3E] text-[#0D3B3E] font-bold text-xs uppercase tracking-widest hover:bg-slate-50 transition-all cursor-pointer text-center rounded-none"
                        >
                          Back
                        </button>
                        <button
                          onClick={() => {
                            if (paymentDetails.cardholder && paymentDetails.cardNumber.length >= 15 && paymentDetails.expiry && paymentDetails.cvc) {
                              setCheckoutStep('processing');
                            } else {
                              alert('Please enter valid credit card details.');
                            }
                          }}
                          className="flex-1 py-4 bg-[#0D3B3E] text-[#BEFD29] hover:bg-[#1a5b60] font-bold text-xs uppercase tracking-widest transition-all shadow-md cursor-pointer text-center rounded-none"
                        >
                          Authorize
                        </button>
                      </div>
                    </motion.div>
                  )}

                  {/* STEP 4: SECURED PROCESSING SCREEN */}
                  {checkoutStep === 'processing' && (
                    <motion.div
                      key="processing-step"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      className="py-12 flex flex-col items-center justify-center space-y-6 text-center"
                    >
                      <div className="relative">
                        <div className="w-16 h-16 rounded-full border-4 border-slate-100 border-t-[#0D3B3E] animate-spin" />
                        <Lock className="w-6 h-6 text-[#BEFD29] absolute inset-0 m-auto" />
                      </div>

                      <div className="space-y-2">
                        <h4 className="font-bold text-base text-[#0D3B3E]">Authorizing Bank Ledger...</h4>
                        <p className="text-xs text-slate-500 max-w-xs">{processingStatus}</p>
                      </div>

                      {/* Progress Line */}
                      <div className="w-full max-w-xs h-2 bg-slate-100 overflow-hidden relative border border-slate-200/50 rounded-none">
                        <div
                          className="h-full bg-[#BEFD29] transition-all duration-300"
                          style={{ width: `${processingProgress}%` }}
                        />
                      </div>
                      <span className="text-[10px] font-mono text-[#0D3B3E] font-bold">{processingProgress}% Complete</span>
                    </motion.div>
                  )}

                  {/* STEP 5: SECURED SUCCESS RECEIPT */}
                  {checkoutStep === 'success' && (
                    <motion.div
                      key="success-step"
                      initial={{ opacity: 0, scale: 0.95 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className="space-y-6 text-center py-6"
                    >
                      <div className="w-14 h-14 bg-[#BEFD29] border border-[#0D3B3E]/10 rounded-full flex items-center justify-center mx-auto text-[#0D3B3E] shadow-md">
                        <Check className="w-7 h-7" />
                      </div>

                      <div className="space-y-1">
                        <h4 className="text-xl font-bold text-[#0D3B3E] tracking-tight">Sanctuary Secured!</h4>
                        <p className="text-xs text-slate-500">Your order has been authorized with strict security.</p>
                      </div>

                      <div className="p-5 rounded-none bg-slate-50 border-2 border-[#0D3B3E] text-left space-y-3.5">
                        <div className="flex justify-between items-center text-xs pb-2.5 border-b border-[#0D3B3E]/10 font-mono">
                          <span className="text-slate-400 uppercase font-bold text-[9px]">Secure Reference ID</span>
                          <span className="text-[#0D3B3E] font-bold">{orderId}</span>
                        </div>

                        <div className="text-xs space-y-1">
                          <p className="text-slate-400 uppercase font-bold text-[9px] font-mono">Recipient</p>
                          <p className="text-[#0D3B3E] font-semibold">{shippingDetails.fullName}</p>
                          <p className="text-slate-500 leading-normal">{shippingDetails.address}, {shippingDetails.city} {shippingDetails.zip}</p>
                        </div>

                        <div className="text-xs space-y-1 pt-2 border-t border-[#0D3B3E]/10">
                          <p className="text-slate-400 uppercase font-bold text-[9px] font-mono">Setup Security Tip</p>
                          <p className="text-slate-600 leading-normal">
                            Keep your devices running continuously in sleeping quarters. Do not separate from core rooms. Standard delivery will arrive in 2-3 business days.
                          </p>
                        </div>
                      </div>

                      <button
                        onClick={() => {
                          setIsCartOpen(false);
                          setCheckoutStep('cart');
                        }}
                        className="w-full py-4 bg-[#0D3B3E] text-[#BEFD29] text-xs font-bold uppercase tracking-widest transition-all shadow-md cursor-pointer hover:bg-[#155a60] rounded-none"
                      >
                        Keep Exploring Features
                      </button>
                    </motion.div>
                  )}

                </AnimatePresence>

              </div>

              {/* Drawer Footer Secured Badge */}
              <div className="bg-[#0D3B3E] p-4 flex items-center justify-center gap-2 text-[#BEFD29] text-[9px] font-bold uppercase tracking-widest font-mono">
                <Lock className="w-3.5 h-3.5" /> AES-256 SECURED GATEWAY CONNECTIONS
              </div>

            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* 10. Reviews & Trust Guarantee */}
      <section className="py-24 px-6 md:px-12 bg-white border-t border-slate-100">
        <div className="max-w-7xl mx-auto space-y-16">
          
          <div className="text-center space-y-4">
            <span className="text-xs uppercase font-bold tracking-widest text-[#0D3B3E] font-mono bg-[#BEFD29] text-[#0D3B3E] px-4 py-1">
              Verified Comfort
            </span>
            <h2 className="text-3xl md:text-5xl font-bold tracking-tighter text-[#0D3B3E]">
              Trusted by 12,000+ Families
            </h2>
            <p className="text-slate-600 max-w-xl mx-auto text-sm md:text-base leading-relaxed">
              We asked parents why they made the change to BuzzShield’s zapping-free vacuum containment:
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            
            {/* Review 1 */}
            <div className="bg-[#F7F9FA] border-2 border-[#0D3B3E]/5 p-8 rounded-none flex flex-col justify-between space-y-6 shadow-[4px_4px_0px_0px_rgba(13,59,62,0.03)] hover:shadow-[4px_4px_0px_0px_#0D3B3E] transition-all duration-300">
              <p className="text-slate-600 text-xs md:text-sm leading-relaxed italic">
                &ldquo;Having a newborn made us terrified of using chemical plugins or those old high-voltage mosquito zappers that emit popping sounds and smell bad. BuzzShield sits silently on our dresser. The soft blue light acts as a perfect baby nightlight, and we haven&apos;t seen a single mosquito bite in weeks.&rdquo;
              </p>
              <div>
                <h5 className="font-bold text-[#0D3B3E] text-xs uppercase font-mono tracking-wider">Sarah Jenkins</h5>
                <p className="text-slate-400 text-[10px] font-bold">Verified Parent, Austin TX</p>
              </div>
            </div>

            {/* Review 2 */}
            <div className="bg-[#F7F9FA] border-2 border-[#0D3B3E]/5 p-8 rounded-none flex flex-col justify-between space-y-6 shadow-[4px_4px_0px_0px_rgba(13,59,62,0.03)] hover:shadow-[4px_4px_0px_0px_#0D3B3E] transition-all duration-300">
              <p className="text-slate-600 text-xs md:text-sm leading-relaxed italic">
                &ldquo;Our kittens are incredibly curious and jump onto everything. Standard electric zappers are a massive hazard. BuzzShield has a clever protective outer safety cage. It is completely touch-safe, zero chemical, and the matte teal design looks like a modern premium speaker. Absolute peace of mind.&rdquo;
              </p>
              <div>
                <h5 className="font-bold text-[#0D3B3E] text-xs uppercase font-mono tracking-wider">Derrick Vane</h5>
                <p className="text-slate-400 text-[10px] font-bold">Verified Pet Owner, Seattle WA</p>
              </div>
            </div>

            {/* Review 3 */}
            <div className="bg-[#F7F9FA] border-2 border-[#0D3B3E]/5 p-8 rounded-none flex flex-col justify-between space-y-6 shadow-[4px_4px_0px_0px_rgba(13,59,62,0.03)] hover:shadow-[4px_4px_0px_0px_#0D3B3E] transition-all duration-300">
              <p className="text-slate-600 text-xs md:text-sm leading-relaxed italic">
                &ldquo;I live near a lake and stagnant water vectors are high. I completed the online Space Diagnostic and bought the Duo pack. Following the guide, I placed one by the terrace door and one in the bedroom. They run continuously. Not having to spray heavy chemical DEET in my living room is wonderful.&rdquo;
              </p>
              <div>
                <h5 className="font-bold text-[#0D3B3E] text-xs uppercase font-mono tracking-wider">Marcus Thorne</h5>
                <p className="text-slate-400 text-[10px] font-bold">Verified Homeowner, Orlando FL</p>
              </div>
            </div>

          </div>

          {/* Money Back Guarantee Banner */}
          <div className="p-8 md:p-10 rounded-none border-4 border-[#0D3B3E] bg-[#F7F9FA] shadow-[8px_8px_0px_0px_#BEFD29] grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
            <div className="lg:col-span-8 space-y-3">
              <h4 className="text-xl font-bold text-[#0D3B3E] flex items-center gap-2.5 tracking-tight uppercase font-mono text-sm">
                <Shield className="w-5 h-5 text-[#0D3B3E]" /> 30-Day Zero-Mosquito sleep Guarantee
              </h4>
              <p className="text-slate-600 text-xs md:text-sm leading-relaxed">
                We believe your sleep should be sacred. Try BuzzShield in your household for 30 nights. If you are not completely satisfied with the zapping-free, chemical-free tranquility, contact our priority support for a complete security refund.
              </p>
            </div>
            <div className="lg:col-span-4 flex justify-end">
              <a
                href="#buy"
                className="w-full lg:w-auto text-center inline-flex items-center justify-center gap-2 px-8 py-4 bg-[#0D3B3E] text-[#BEFD29] font-bold uppercase tracking-widest text-xs rounded-none transition-all shadow-md cursor-pointer hover:bg-[#155a60]"
              >
                Secure Yours Risk-Free <ArrowRight className="w-4 h-4 text-[#BEFD29]" />
              </a>
            </div>
          </div>

        </div>
      </section>

      {/* 11. Footer */}
      <footer id="app-footer" className="bg-[#1A1A1A] text-white py-16 px-6 md:px-12 border-t border-white/5">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-12">
          <div className="space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 bg-[#0D3B3E] flex items-center justify-center">
                <Shield className="w-4 h-4 text-[#BEFD29]" />
              </div>
              <span className="text-lg font-bold tracking-tighter">BUZZ<span className="text-white/60">SHIELD</span></span>
            </div>
            <p className="text-slate-400 text-xs leading-relaxed">
              Premium modern electric mosquito attraction and containment systems designed for human comfort and non-toxic safety.
            </p>
            <p className="text-[10px] text-slate-500 font-mono uppercase tracking-wider">
              &copy; 2026 BuzzShield Inc. All Rights Reserved.
            </p>
          </div>

          <div>
            <h5 className="font-bold text-xs uppercase font-mono text-[#BEFD29] tracking-widest mb-4">Product Specs</h5>
            <ul className="space-y-2 text-xs text-slate-400">
              <li>365nm Optical Resonance</li>
              <li>18dB Brushless Suction Motor</li>
              <li>USB-C Braided Cable</li>
              <li>Eco-Friendly Soy-Ink Packaging</li>
            </ul>
          </div>

          <div>
            <h5 className="font-bold text-xs uppercase font-mono text-[#BEFD29] tracking-widest mb-4">Official Guideline Sites</h5>
            <ul className="space-y-2 text-xs text-slate-400">
              <li>
                <a href="https://www.cdc.gov/mosquitoes/prevention/index.html" target="_blank" rel="noreferrer" className="hover:text-white flex items-center gap-1">
                  CDC Prevention <ExternalLink className="w-3 h-3 text-[#BEFD29]" />
                </a>
              </li>
              <li>
                <a href="https://www.who.int/news-room/fact-sheets/detail/vector-borne-diseases" target="_blank" rel="noreferrer" className="hover:text-white flex items-center gap-1">
                  WHO Vector control <ExternalLink className="w-3 h-3 text-[#BEFD29]" />
                </a>
              </li>
              <li>
                <a href="https://www.epa.gov/insect-repellents" target="_blank" rel="noreferrer" className="hover:text-white flex items-center gap-1">
                  EPA Insect Safety <ExternalLink className="w-3 h-3 text-[#BEFD29]" />
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h5 className="font-bold text-xs uppercase font-mono text-[#BEFD29] tracking-widest mb-4">Sleep Guarantee</h5>
            <p className="text-slate-400 text-xs leading-relaxed">
              Every purchase is secure under PCI-DSS standards. We support eco-friendly unboxing protocols and non-zap pediatric-safe sleep protection.
            </p>
          </div>
        </div>
      </footer>

    </div>
  );
}
