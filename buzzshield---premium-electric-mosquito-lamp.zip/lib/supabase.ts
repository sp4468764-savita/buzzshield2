import { createClient } from '@supabase/supabase-js';

// Securely access credentials. We prioritize process.env and fallback to the user's provided keys.
const supabaseUrl = process.env.SUPABASE_URL || 'https://qqyjjnmqytlmxpgnxlak.supabase.co';
const supabaseKey = process.env.SUPABASE_ANON_KEY || 'sb_publishable_9ouOgb5OmNf3YM9j1Af9xA_LMzZZxP0';

let supabaseClient: any = null;

export function getSupabaseClient() {
  if (!supabaseClient) {
    if (!supabaseUrl || !supabaseKey) {
      throw new Error('Supabase URL and API Key are required. Please configure SUPABASE_URL and SUPABASE_ANON_KEY in your settings.');
    }
    supabaseClient = createClient(supabaseUrl, supabaseKey);
  }
  return supabaseClient;
}
